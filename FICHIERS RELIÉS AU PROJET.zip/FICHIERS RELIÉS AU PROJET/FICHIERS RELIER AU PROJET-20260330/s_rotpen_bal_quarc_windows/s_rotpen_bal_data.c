/*
 * s_rotpen_bal_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "s_rotpen_bal".
 *
 * Model version              : 1.365
 * Simulink Coder version : 25.1 (R2025a) 21-Nov-2024
 * C source code generated on : Fri Apr 10 13:10:42 2026
 *
 * Target selection: quarc_windows.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-32 (Windows32)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "s_rotpen_bal.h"

/* Block parameters (default storage) */
P_s_rotpen_bal_T s_rotpen_bal_P = {
  /* Variable: A
   * Referenced by: '<Root>/Inverted Pendulum  Model'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 81.403282316061237, 122.05453269367533, 1.0,
    0.0, -45.825874724972323, -44.096596433463937, 0.0, 1.0, -0.931881802111452,
    -1.3972458437343844 },

  /* Variable: B
   * Referenced by: '<Root>/Inverted Pendulum  Model'
   */
  { 0.0, 0.0, 83.4659030959617, 80.31624637535937 },

  /* Variable: C
   * Referenced by: '<Root>/Inverted Pendulum  Model'
   */
  { 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0 },

  /* Variable: K
   * Referenced by: '<Root>/Control  Gain'
   */
  { -5.2611594041446281, 28.156832506281294, -2.7575722473643638,
    3.2190269048473135 },

  /* Expression: 0
   * Referenced by: '<Root>/Inverted Pendulum  Model'
   */
  0.0,

  /* Expression: 180/pi
   * Referenced by: '<S5>/Gain'
   */
  57.295779513082323,

  /* Expression: 1
   * Referenced by: '<Root>/Signal Generator'
   */
  1.0,

  /* Expression: 0.1
   * Referenced by: '<Root>/Signal Generator'
   */
  0.1,

  /* Expression: 20
   * Referenced by: '<Root>/Amplitude (deg)'
   */
  20.0,

  /* Expression: pi/180
   * Referenced by: '<S1>/Gain1'
   */
  0.017453292519943295,

  /* Expression: [1,0,0,0]
   * Referenced by: '<Root>/Convert to  Vector State'
   */
  { 1.0, 0.0, 0.0, 0.0 },

  /* Expression: 180/pi
   * Referenced by: '<S6>/Gain'
   */
  57.295779513082323,

  /* Computed Parameter: HPFtheta_dotrads_A
   * Referenced by: '<S2>/HPF: theta_dot (rad//s)'
   */
  -62.831853071795862,

  /* Computed Parameter: HPFtheta_dotrads_C
   * Referenced by: '<S2>/HPF: theta_dot (rad//s)'
   */
  -3947.8417604357433,

  /* Computed Parameter: HPFtheta_dotrads_D
   * Referenced by: '<S2>/HPF: theta_dot (rad//s)'
   */
  62.831853071795862,

  /* Computed Parameter: HPFalpha_dotrads_A
   * Referenced by: '<S2>/HPF: alpha_dot (rad//s)'
   */
  -62.831853071795862,

  /* Computed Parameter: HPFalpha_dotrads_C
   * Referenced by: '<S2>/HPF: alpha_dot (rad//s)'
   */
  -3947.8417604357433,

  /* Computed Parameter: HPFalpha_dotrads_D
   * Referenced by: '<S2>/HPF: alpha_dot (rad//s)'
   */
  62.831853071795862
};

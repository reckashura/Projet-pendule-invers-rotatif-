/*
 * s_rotpen_bal_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "s_rotpen_bal".
 *
 * Model version              : 1.365
 * Simulink Coder version : 25.1 (R2025a) 21-Nov-2024
 * C source code generated on : Fri Apr 10 13:10:42 2026
 *
 * Target selection: quarc_windows.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-32 (Windows32)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef s_rotpen_bal_private_h_
#define s_rotpen_bal_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "s_rotpen_bal_types.h"

/* private model entry point functions */
extern void s_rotpen_bal_derivatives(void);

#endif                                 /* s_rotpen_bal_private_h_ */

/*
 * q_rotpen_mdl_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "q_rotpen_mdl".
 *
 * Model version              : 1.368
 * Simulink Coder version : 25.1 (R2025a) 21-Nov-2024
 * C source code generated on : Tue Mar 31 19:52:35 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef q_rotpen_mdl_types_h_
#define q_rotpen_mdl_types_h_

/* Parameters (default storage) */
typedef struct P_q_rotpen_mdl_T_ P_q_rotpen_mdl_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_q_rotpen_mdl_T RT_MODEL_q_rotpen_mdl_T;

#endif                                 /* q_rotpen_mdl_types_h_ */

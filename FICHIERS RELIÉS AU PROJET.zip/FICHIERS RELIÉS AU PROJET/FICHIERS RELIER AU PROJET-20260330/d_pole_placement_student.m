% IMPORTANT: Make sure you run setup_rotpen.m first. You need the (A,B)
% state-space matrices.
%
%% Find Tranformation Matrix W
% Characteristic equation: s^4 + a_4*s^3 + a_3*s^2 + a_2*s + a_1
a = poly(A);
% 
% Companion matrices (Ac, Bc)
Ac = [  0 1 0 0;
        0 0 1 0;
        0 0 0 1;
        -a(5) -a(4) -a(3) -a(2)];
%
Bc = [0; 0; 0; 1];
%
% Controllability
T = ctrb(A,B); 
% Controllability of companion matrices
Tc = ctrb(Ac,Bc);
% Inverse of controllability matrix of companion form
Tc_inv = inv(Tc);
% Transformation matrices
W = T * Tc_inv;
disp('Ac =')
disp(Ac)

disp('Bc =')
disp(Bc)

disp('T =')
disp(T)

disp('Tc =')
disp(Tc)

disp('Tc_inv =')
disp(Tc_inv)

disp('W =')
disp(W)
%
%% Find Gain
% Companion state-feedback control gain
Kc = [19200 9843.6486 1707.1202 28.3769];
% Convert back from companion form
K = Kc / W;

disp('Kc =')
disp(Kc)

disp('K =')
disp(K)
%
%% Closed-loop System Poles
% Find poles of closed-loop system. 
Acl = A - B*K;

disp('A - B*K =')
disp(Acl)

% Verify that they are the same as the desired poles.
cls_poles = eig(Acl);

disp('Poles en boucle fermee =')
disp(cls_poles)

% Calcule du gain en utilisant commande de placement de pole
K_com = place(A,B,cls_poles)

set "VSCMD_START_DIR=%CD%"
"C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\VCVARSALL.BAT " AMD64